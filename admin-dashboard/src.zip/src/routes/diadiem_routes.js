const express = require('express');
const locationController = require('../controllers/diadiem_controller'); // Bạn cần tạo controller này
const authMiddleware = require('../middlewares/auth_middleware');
const validationMiddleware = require('../middlewares/validation_middleware');
// const { body, param, query } = require('express-validator'); // Import nếu dùng trực tiếp ở đây

const router = express.Router();

router.use(authMiddleware.authenticateToken);
router.use(authMiddleware.authorizeRole(['admin']));

router.post(
    '/',
    locationController.locationValidationRules(),
    validationMiddleware,
    locationController.createLocation
);

router.get(
    '/',
    locationController.getAllLocationsQueryValidationRules(),
    validationMiddleware,
    locationController.getAllLocations
);

router.get(
    '/:id_dia_diem',
    // param('id_dia_diem').isInt({ min: 1 }).withMessage('ID địa điểm không hợp lệ.'),
    validationMiddleware,
    locationController.getLocationById
);

router.put(
    '/:id_dia_diem',
    locationController.locationValidationRules(), // Có thể cần rule riêng cho update
    validationMiddleware,
    locationController.updateLocation
);

router.delete(
    '/:id_dia_diem',
    // param('id_dia_diem').isInt({ min: 1 }).withMessage('ID địa điểm không hợp lệ.'),
    validationMiddleware,
    locationController.deleteLocation
);

module.exports = router;
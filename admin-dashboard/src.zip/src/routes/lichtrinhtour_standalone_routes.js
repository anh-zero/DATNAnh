const express = require('express');
const router = express.Router();
const { param } = require('express-validator');
const {
    TourScheduleController,
    scheduleValidationRules,
    updateScheduleValidationRules
} = require('../controllers/lichtrinhtour_controller');
const validationMiddleware = require('../middlewares/validation_middleware');
const authMiddleware = require('../middlewares/auth_middleware');

// Áp dụng middleware xác thực
router.use(authMiddleware.authenticateToken);
router.use(authMiddleware.authorizeRole(['admin'])); // hoặc các role phù hợp

// GET /lichtrinhtour - Lấy danh sách lịch trình
router.get('/', TourScheduleController.getAllTourSchedules);

// POST /lichtrinhtour - Tạo mới lịch trình tour
router.post(
    '/',
    scheduleValidationRules(),
    validationMiddleware,
    TourScheduleController.createTourSchedule
);

// GET /api/schedules/:id_lich_trinh_tour
router.get(
    '/:id_lich_trinh_tour',
    param('id_lich_trinh_tour').isInt({ min: 1 }).withMessage('ID lịch trình không hợp lệ.'),
    validationMiddleware,
    TourScheduleController.getTourScheduleById  // Thay tourScheduleController thành TourScheduleController
);

// PUT /api/schedules/:id_lich_trinh_tour
router.put(
    '/:id_lich_trinh_tour',
    updateScheduleValidationRules(), // Thay tourScheduleController.updateScheduleValidationRules()
    validationMiddleware,
    TourScheduleController.updateTourSchedule  // Thay tourScheduleController thành TourScheduleController
);

// DELETE /api/schedules/:id_lich_trinh_tour
router.delete(
    '/:id_lich_trinh_tour',
    param('id_lich_trinh_tour').isInt({ min: 1 }).withMessage('ID lịch trình không hợp lệ.'),
    validationMiddleware,
    TourScheduleController.deleteTourSchedule  // Thay tourScheduleController thành TourScheduleController
);

// PATCH /api/schedules/:id_lich_trinh_tour/cancel
router.patch(
    '/:id_lich_trinh_tour/cancel',
    param('id_lich_trinh_tour').isInt({ min: 1 }).withMessage('ID lịch trình không hợp lệ.'),
    // Thêm validation cho 'reason' nếu cần
    validationMiddleware,
    TourScheduleController.cancelTourSchedule  // Thay tourScheduleController thành TourScheduleController
);

// Nested routes for services and activities related to this schedule
const tourProvidedServiceRoutes = require('./dichvutour_standalone_routes');
const tourActivityRoutes = require('./hoatdongtour_standalone_routes');

router.use('/:id_lich_trinh_tour/provided-services', tourProvidedServiceRoutes);
router.use('/:id_lich_trinh_tour/activities', tourActivityRoutes);

module.exports = router;
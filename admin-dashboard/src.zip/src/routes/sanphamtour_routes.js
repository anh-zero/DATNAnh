const express = require('express');
const tourController = require('../controllers/sanphamtour_controller');
const authMiddleware = require('../middlewares/auth_middleware');
const validationMiddleware = require('../middlewares/validation_middleware');
const uploadMiddleware = require('../middlewares/upload_middleware');
const tourScheduleRoutes = require('./lichtrinhtour_standalone_routes'); // Lồng route cho schedules

const router = express.Router();

router.use(authMiddleware.authenticateToken);
router.use(authMiddleware.authorizeRole(['admin']));

router.post(
    '/',
    uploadMiddleware.single('url_anh_bia'),
    tourController.tourValidationRules(), // Đảm bảo rules này không còn 'partners'
    validationMiddleware,
    tourController.createTour
);

router.get(
    '/',
    tourController.getAllToursQueryValidationRules(),
    validationMiddleware,
    tourController.getAllTours
);

router.get('/statistics', tourController.getTourStatistics); // Route thống kê

router.get(
    '/:id_san_pham_tour',
    // param('id_san_pham_tour').isInt({ min: 1 }).withMessage('ID sản phẩm tour không hợp lệ.'), // Đã có trong updateTourValidationRules
    validationMiddleware,
    tourController.getTourById
);

router.put(
    '/:id_san_pham_tour',
    uploadMiddleware.single('url_anh_bia'),
    tourController.updateTourValidationRules(), // Đảm bảo rules này không còn 'partners'
    validationMiddleware,
    tourController.updateTour
);

router.delete(
    '/:id_san_pham_tour',
    // param('id_san_pham_tour').isInt({ min: 1 }).withMessage('ID sản phẩm tour không hợp lệ.'),
    validationMiddleware,
    tourController.deleteTour
);

// Nested routes for schedules of a specific tour
// /api/tours/:id_san_pham_tour/schedules
router.use('/:id_san_pham_tour/schedules', tourScheduleRoutes);


module.exports = router;

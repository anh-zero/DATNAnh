// File: src/utils/api_response.js

const successResponse = (res, message, data = null, statusCode = 200) => {
    const response = {
        success: true,
        message: message,
    };
    if (data) {
        response.data = data;
    }
    return res.status(statusCode).json(response);
};

const errorResponse = (res, message, statusCode = 500, errors = null) => {
    const response = {
        success: false,
        message: message,
    };
    if (errors) {
        response.errors = errors;
    }
    return res.status(statusCode).json(response);
};

const paginatedResponse = ({ res, statusCode = 200, message, data, currentPage, totalCount, limit }) => {
    // Convert tất cả tham số sang kiểu số nguyên (nếu chưa)
    const safeCurrentPage = Number(currentPage) || 1;
    const safeTotalCount = Number(totalCount) || 0;
    const safeLimit = Number(limit) || 10;

    // Tính totalPages
    const totalPages = Math.ceil(safeTotalCount / safeLimit);

    return res.status(statusCode).json({
        success: true,
        message,
        data: data || [], // Đảm bảo data không là null/undefined
        pagination: {
            currentPage: safeCurrentPage,
            totalPages,
            limit: safeLimit,
            totalCount: safeTotalCount
        }
    });
};


module.exports = {
    successResponse,
    errorResponse,
    paginatedResponse
};